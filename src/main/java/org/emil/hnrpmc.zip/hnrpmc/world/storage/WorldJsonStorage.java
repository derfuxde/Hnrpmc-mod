package org.emil.hnrpmc.world.storage;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;
import org.emil.hnrpmc.simpleclans.SimpleClans;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public final class WorldJsonStorage {

    private static final Gson GSON = SimpleClans.getInstance().getGSON();//new GsonBuilder().setPrettyPrinting().create();
    private static final Type MAP_TYPE = new TypeToken<Map<String, Boolean>>(){}.getType();

    public static Path filePath(MinecraftServer server) {
        Path configDir = Path.of(server.getWorldPath(LevelResource.ROOT).toString().replace(".", "") + "serverconfig");
        return configDir.resolve("worldprotsave.json");
    }

    public static Map<String, Boolean> load(MinecraftServer server) {
        Path path = filePath(server);
        try {
            if (!Files.exists(path)) {
                Files.createDirectories(path.getParent());
                // FIX: Speichere die Standard-Regeln als echtes JSON, wenn keine Datei existiert
                save(new HashMap<>(defaultrules), server);
                return new HashMap<>(defaultrules);
            }
            String json = Files.readString(path, StandardCharsets.UTF_8);
            Map<String, Boolean> map = GSON.fromJson(json, MAP_TYPE);
            return map != null ? map : new HashMap<>(defaultrules);
        } catch (IOException e) {
            e.printStackTrace(); // Logge den Fehler, um Probleme zu finden
            return new HashMap<>(defaultrules);
        }
    }

    public static void save(Map<String, Boolean> rules, MinecraftServer server) {
        Path path = filePath(server);
        try {
            Files.createDirectories(path.getParent());
            String json = GSON.toJson(rules, MAP_TYPE);
            Files.writeString(path, json, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Standard-Regeln
    public static final Map<String, Boolean> defaultrules = new HashMap<>();

    static {
        defaultrules.put("pvp", true);
        defaultrules.put("creeper_explosions", true);
        defaultrules.put("creeper_explode_items", true);
        defaultrules.put("creeper_explode_blocks", true);
        defaultrules.put("creeper_explode_damage", true);
        defaultrules.put("tnt_explosions", true);
        defaultrules.put("tnt_explode_items", true);
        defaultrules.put("tnt_explode_blocks", true);
        defaultrules.put("tnt_explode_damage", true);
        defaultrules.put("crystal_explosions", true);
        defaultrules.put("crystal_explode_items", true);
        defaultrules.put("crystal_explode_blocks", true);
        defaultrules.put("crystal_explode_damage", true);
        defaultrules.put("placing", true);
        defaultrules.put("mining", true);
    }

    private WorldJsonStorage() {}
}