package org.emil.hnrpmc.world;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.PermissionHolder;
import net.luckperms.api.model.user.User;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import org.emil.hnrpmc.world.storage.WorldJsonStorage;
import net.neoforged.neoforge.server.permission.PermissionAPI;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;


public class WorldProtCommands {
    public static final Map<String, String> ProtItems = new HashMap<>();
    static{
        ProtItems.put("pvp", "PvP ist ");
        ProtItems.put("creeper_explosions", "Creeper Explosionen sind ");
        ProtItems.put("creeper_explode_items", "Creeper Item Schaden ist ");
        ProtItems.put("creeper_explode_blocks", "Creeper Block Schaden ist ");
        ProtItems.put("creeper_explode_damage", "Creeper Explosions Schaden ist ");
        ProtItems.put("tnt_explosions", "Tnt Explosionen sind ");
        ProtItems.put("tnt_explode_items", "Tnt Item Schaden ist ");
        ProtItems.put("tnt_explode_blocks", "Tnt Block Schaden ist ");
        ProtItems.put("tnt_explode_damage", "Tnt Explosions Schaden ist ");
        ProtItems.put("crystal_explosions", "Crystal Explosionen sind ");
        ProtItems.put("crystal_explode_items", "Crystal Item Schaden ist ");
        ProtItems.put("crystal_explode_blocks", "Crystal Block Schaden ist ");
        ProtItems.put("crystal_explode_damage", "Crystal Explosions Schaden ist ");
        ProtItems.put("placing", "Block plazieren ist ");
        ProtItems.put("mining", "Block zerstören ist ");
    }
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(literal("worldprot")
                .requires(source -> {
                    if (source.hasPermission(2)) return true;
                    if (source.getEntity() instanceof ServerPlayer p) {
                        User user = LuckPermsProvider.get().getUserManager().getUser(p.getUUID());
                        if (user == null) return false;

                        return user.getCachedData().getPermissionData().checkPermission("hnrpmc.world.worldprot").asBoolean(); //("hnrpmc.world.worldprot");
                    }
                    return false;
                })

                .executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    Map<String, Boolean> rules = WorldJsonStorage.load(p.server);
                    List<String> printer = List.of();
                    for (Map.Entry<String, Boolean> entry : rules.entrySet()) {
                        String aktiv = entry.getValue() == true ? "aktiviert" : "deaktiviert";
                        printer.add(ProtItems.get(entry.getKey()) + aktiv);
                    }
                    return 1;
                })
                .then(Commands.argument("type", StringArgumentType.word())
                        .suggests((context, builder) -> {
                            builder.suggest("pvp");
                            builder.suggest("creeper_explosions");
                            builder.suggest("creeper_explode_items");
                            builder.suggest("creeper_explode_blocks");
                            builder.suggest("creeper_explode_damage");
                            builder.suggest("tnt_explosions");
                            builder.suggest("tnt_explode_items");
                            builder.suggest("tnt_explode_blocks");
                            builder.suggest("tnt_explode_damage");
                            builder.suggest("crystal_explosions");
                            builder.suggest("crystal_explode_items");
                            builder.suggest("crystal_explode_blocks");
                            builder.suggest("crystal_explode_damage");
                            builder.suggest("placing");
                            builder.suggest("mining");
                            return builder.buildFuture();
                        })
                        .executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            Map<String, Boolean> rules = WorldJsonStorage.load(p.server);
                            String auswahl = StringArgumentType.getString(ctx, "type");
                            if (rules.containsKey(auswahl)) {
                                rules.replace(auswahl, !rules.get(auswahl));
                                String aktiv = rules.get(auswahl) == true ? "aktiviert" : "deaktiviert";
                                p.sendSystemMessage(Component.literal( ProtItems.get(auswahl) + aktiv));
                                WorldJsonStorage.save(rules, p.server);
                                return 1;
                            }else {
                                rules.put(auswahl, true);
                                String aktiv = rules.get(auswahl) == true ? "aktiviert" : "deaktiviert";
                                p.sendSystemMessage(Component.literal( ProtItems.get(auswahl) + aktiv));
                                WorldJsonStorage.save(rules, p.server);
                                return 1;
                            }
                        })
                )
        );
    }
}
