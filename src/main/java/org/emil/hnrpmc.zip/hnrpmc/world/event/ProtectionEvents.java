package org.emil.hnrpmc.world.event;

import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.MinecartTNT;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.level.ExplosionEvent;
import org.emil.hnrpmc.world.storage.WorldJsonStorage;

import java.util.Map;

@EventBusSubscriber(modid = "hnrpmc")
public class ProtectionEvents {

    // Hilfsmethode für Nachrichten und Permission-Check
    private static boolean canBypass(Entity entity, String type) {
        if (entity instanceof ServerPlayer player) {
            // 1. Creative Mode Check
            //if (player.getAbilities().instabuild) return true;

            User user = LuckPermsProvider.get().getUserManager().getUser(player.getUUID());
            if (user == null) return false;

            return user.getCachedData().getPermissionData().checkPermission("hnrpmc.world." + type).asBoolean();
            //return player.hasPermissions(0); // Platzhalter, siehe unten für die richtige API
        }
        return false;
    }

    private static void notifyPlayer(Entity entity, String message) {
        if (entity instanceof ServerPlayer player) {
            player.sendSystemMessage(Component.literal("§c" + message));
        }
    }

    // --- 1. EXPLOSION START ---
    @SubscribeEvent
    public static void onExplosionStart(ExplosionEvent.Start event) {
        var server = event.getLevel().getServer();
        if (server == null) return;
        Map<String, Boolean> rules = WorldJsonStorage.load(server);

        Entity source = event.getExplosion().getDirectSourceEntity();
        Entity indirect = event.getExplosion().getIndirectSourceEntity();

        if (source instanceof Creeper && !rules.getOrDefault("creeper_explosions", true)) {
            if (!canBypass(indirect, "creeper")) event.setCanceled(true);
        }
        else if ((source instanceof PrimedTnt || source instanceof MinecartTNT) && !rules.getOrDefault("tnt_explosions", true)) {
            if (!canBypass(indirect, "tnt")) {
                notifyPlayer(indirect, "TNT-Explosionen sind hier deaktiviert!");
                event.setCanceled(true);
            }
        }
        else if (source instanceof EndCrystal && !rules.getOrDefault("crystal_explosions", true)) {
            if (!canBypass(indirect, "crystal")) {
                notifyPlayer(indirect, "Kristall-Explosionen sind hier deaktiviert!");
                event.setCanceled(true);
            }
        }
    }

    // --- 2. EXPLOSION DETONATE (Blöcke & Items) ---
    @SubscribeEvent
    public static void onExplosionDetonate(ExplosionEvent.Detonate event) {
        var server = event.getLevel().getServer();
        if (server == null) return;
        Map<String, Boolean> rules = WorldJsonStorage.load(server);
        Entity indirect = event.getExplosion().getIndirectSourceEntity();

        Entity source = event.getExplosion().getDirectSourceEntity();
        String type = (source instanceof Creeper) ? "creeper" :
                (source instanceof PrimedTnt || source instanceof MinecartTNT) ? "tnt" :
                        (source instanceof EndCrystal) ? "crystal" : "";

        if (!type.isEmpty() && !canBypass(indirect, type)) {
            if (!rules.getOrDefault(type + "_explode_blocks", true)) event.getAffectedBlocks().clear();
            if (!rules.getOrDefault(type + "_explode_items", true)) event.getAffectedEntities().removeIf(e -> e instanceof ItemEntity);
        }
    }

    // --- 3. SCHADEN (PvP & Explosion Damage) ---
    @SubscribeEvent
    public static void onDamage(LivingIncomingDamageEvent event) {
        var server = event.getEntity().getServer();
        if (server == null) return;
        Map<String, Boolean> rules = WorldJsonStorage.load(server);

        Entity attacker = event.getSource().getEntity();
        Entity directSource = event.getSource().getDirectEntity();

        // PvP Bypass
        if (event.getEntity() instanceof Player && attacker instanceof Player) {
            if (!rules.getOrDefault("pvp", true) && !canBypass(attacker, "pvp")) {
                event.setCanceled(true);
                return;
            }
        }

        // Explosion Damage Bypass
        if (directSource instanceof Creeper && !rules.getOrDefault("creeper_explode_damage", true)) {
            if (!canBypass(attacker, "creeper")) event.setCanceled(true);
        }
        else if ((directSource instanceof PrimedTnt || directSource instanceof MinecartTNT) && !rules.getOrDefault("tnt_explode_damage", true)) {
            if (!canBypass(attacker, "tnt")) event.setCanceled(true);
        }
        else if (directSource instanceof EndCrystal && !rules.getOrDefault("crystal_explode_damage", true)) {
            if (!canBypass(attacker, "crystal")) event.setCanceled(true);
        }
    }

    // --- 4. MINING ---
    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        if (!WorldJsonStorage.load(event.getPlayer().getServer()).getOrDefault("mining", true)) {
            if (!canBypass(event.getPlayer(), "mining")) {
                notifyPlayer(event.getPlayer(), "Abbauen ist hier deaktiviert!");
                event.setCanceled(true);
            }
        }
    }

    // --- 5. PLACING ---
    @SubscribeEvent
    public static void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        if (event.getEntity() instanceof Player player) {
            if (!WorldJsonStorage.load(player.getServer()).getOrDefault("placing", true)) {
                if (!canBypass(player, "placing")) {
                    notifyPlayer(player, "Bauen ist hier deaktiviert!");
                    event.setCanceled(true);
                }
            }
        }
    }
}