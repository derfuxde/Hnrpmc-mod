package org.emil.hnrpmc.simpleclans;

/**
 * Possible vote values
 *
 * @author cc_madelg
 */
public enum VoteResult {
    ACCEPT, DENY
}
