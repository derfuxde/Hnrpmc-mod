package org.emil.hnrpmc.simpleclans.commands.staff;

import co.aikar.commands.BaseCommand;
import co.aikar.commands.annotation.*;
import net.minecraft.ChatFormatting;
import net.minecraft.server.level.ServerPlayer;
import org.emil.hnrpmc.simpleclans.ChatBlock;
import org.emil.hnrpmc.simpleclans.Clan;
import org.emil.hnrpmc.simpleclans.commands.ClanInput;
import org.emil.hnrpmc.simpleclans.managers.ClanManager;
import org.emil.hnrpmc.simpleclans.managers.SettingsManager;
import org.emil.hnrpmc.simpleclans.managers.StorageManager;
import net.minecraft.world.entity.player.Player;

import static org.emil.hnrpmc.simpleclans.SimpleClans.lang;

@CommandAlias("%clan")
@Conditions("%basic_conditions")
@Subcommand("%mod %bb")
public class BbCommand extends BaseCommand {

    @Dependency
    private StorageManager storage;
    @Dependency
    private ClanManager cm;

    @Dependency
    private SettingsManager settings;

    @Subcommand("%display")
    @CommandPermission("simpleclans.mod.bb")
    @CommandCompletion("@clans")
    @Description("{@@command.description.mod.bb.display}")
    public void display(Player sender, @Name("clan") ClanInput input) {
        input.getClan().displayBb(sender);
    }

    @Subcommand("%clear")
    @CommandPermission("simpleclans.mod.bb-clear")
    @CommandCompletion("@clans")
    @Description("{@@command.description.mod.bb.clear}")
    public void clear(Player player, @Name("clan") ClanInput input) {
        input.getClan().clearBb();
        ChatBlock.sendMessage(player.createCommandSourceStack(), ChatFormatting.RED + lang("cleared.bb", player));
    }

    @Subcommand("%add")
    @CommandPermission("simpleclans.mod.bb-add")
    @CommandCompletion("@clans @nothing")
    @Description("{@@command.description.mod.bb.post}")
    public void postMessage(Player player, @Name("clan") ClanInput input, @Name("message") String msg) {
        Clan clan = input.getClan();
        clan.addBb(lang("bulletin.board.message", player, msg));
        clan.displayBb(player);
        storage.updateClan(clan);
    }

}
