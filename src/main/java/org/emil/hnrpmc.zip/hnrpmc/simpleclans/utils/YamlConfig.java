package org.emil.hnrpmc.simpleclans.utils;

import com.google.gson.Gson;
import org.emil.hnrpmc.simpleclans.SimpleClans;
import org.emil.hnrpmc.simpleclans.managers.SettingsManager;

import java.io.*;
import java.util.*;

public class YamlConfig {
    private final File file;
    private Map<String, Object> data = copyDefaultConfig();
    // Gson mit PrettyPrinting (sieht dann sauber aus wie YAML)
    private final Gson gson = SimpleClans.getInstance().getGSON();

    public YamlConfig(File file) {
        this.file = file;
    }

    public void load() {
        // 1. Wenn die Datei nicht existiert, versuchen wir sie aus der JAR zu erstellen
        if (!file.exists()) {
            SimpleClans.getInstance().getLogger().warn("kein file ... wird erstellt");
            save();
        }

        // 2. Jetzt lesen wir die Datei ein
        try (Reader reader = new FileReader(file)) {
            // GSON liest die JSON-Struktur in eine Map
            java.lang.reflect.Type type = new com.google.common.reflect.TypeToken<Map<String, Object>>(){}.getType();
            Map<String, Object> loaded = gson.fromJson(reader, type);

            if (loaded != null) {
                this.data = loaded;
            } else {
                // Falls die Datei leer war, initialisieren wir zumindest eine leere Map
                this.data = copyDefaultConfig();
            }
        } catch (IOException e) {
            SimpleClans.getInstance().getLogger().error("Fehler beim Laden der Konfiguration: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void save() {
        if (data == null || data.isEmpty()) {
            data = copyDefaultConfig();
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
            // Starte die rekursive Speicherung
            writeYamlLevel(writer, data, 0);
        } catch (IOException e) {
            SimpleClans.getInstance().getLogger().error("Fehler beim Speichern der Config", e);
        }
    }

    private void writeYamlLevel(PrintWriter writer, Map<String, Object> map, int indent) {
        String spaces = "  ".repeat(indent); // Erzeugt 2 Leerzeichen pro Ebene

        // Wir sortieren die Keys alphabetisch, damit die Config immer gleich aussieht
        List<String> sortedKeys = new ArrayList<>(map.keySet());
        Collections.sort(sortedKeys);

        for (String key : sortedKeys) {
            Object value = map.get(key);

            if (value instanceof Map) {
                // Wenn der Wert eine Unter-Map ist -> Kategorie schreiben und tiefer gehen
                writer.println(spaces + key + ":");
                writeYamlLevel(writer, (Map<String, Object>) value, indent + 1);
            } else if (value instanceof List) {
                // Listen-Formatierung
                writer.println(spaces + key + ": []");
            } else {
                // Normaler Wert (String, Boolean, Number)
                String outputValue = formatValue(value);
                writer.println(spaces + key + ": " + outputValue);
            }
        }
    }

    private String formatValue(Object value) {
        if (value instanceof String s) {
            // Strings in Anführungszeichen setzen, falls sie Sonderzeichen wie & enthalten
            return "'" + s.replace("'", "''") + "'";
        }
        return String.valueOf(value);
    }

    private Map<String, Object> copyDefaultConfig() {
        Map<String, Object> root = new HashMap<>();

        for (SettingsManager.ConfigField field : SettingsManager.ConfigField.values()) {
            Object value = field.getDefaultValue() != null ? field.getDefaultValue() : "";

            // Wir teilen den Pfad bei jedem Punkt (z.B. "tag.bracket.left")
            String[] parts = field.getPath().split("\\.");
            Map<String, Object> currentMap = root;

            // Wir gehen durch alle Teile außer dem letzten
            for (int i = 0; i < parts.length - 1; i++) {
                String part = parts[i];
                // Falls die Map für diesen Teil noch nicht existiert, erstellen wir sie
                currentMap = (Map<String, Object>) currentMap.computeIfAbsent(part, k -> new HashMap<String, Object>());
            }

            // Der letzte Teil erhält den eigentlichen Wert
            currentMap.put(parts[parts.length - 1], value);
        }

        return root;
    }

    @SuppressWarnings("unchecked")
    public Object get(String path) {
        String[] keys = path.split("\\.");
        Object current = data;
        for (String key : keys) {
            if (!(current instanceof Map)) return null;
            current = ((Map<String, Object>) current).get(key);
        }
        return current;
    }

    @SuppressWarnings("unchecked")
    public void set(String path, Object value) {
        String[] keys = path.split("\\.");
        Map<String, Object> current = data;
        for (int i = 0; i < keys.length - 1; i++) {
            current = (Map<String, Object>) current.computeIfAbsent(keys[i], k -> new HashMap<String, Object>());
        }
        current.put(keys[keys.length - 1], value);
    }

    public String getString(String path, String def) {
        Object val = get(path);
        return (val != null) ? val.toString() : def;
    }

    public boolean getBoolean(String path, boolean def) {
        Object val = get(path);
        return (val instanceof Boolean) ? (Boolean) val : def;
    }

    @SuppressWarnings("unchecked")
    public List<String> getStringList(String path) {
        Object val = get(path);
        if (val instanceof List) return (List<String>) val;
        return new ArrayList<>();
    }
}