//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package org.emil.hnrpmc.simpleclans.conversation.dings;

import org.emil.hnrpmc.simpleclans.conversation.SCConversation;
import org.jetbrains.annotations.NotNull;

public class NullConvoPrefix implements ConvoPrefix {
    public @NotNull String getPrefix(@NotNull SCConversation context) {
        return "";
    }
}
