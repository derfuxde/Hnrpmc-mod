package org.emil.hnrpmc.simpleclans.events;

import net.neoforged.bus.api.Event; // WICHTIGER IMPORT
import org.emil.hnrpmc.simpleclans.Clan;

public class CreateClanEvent extends Event {
    private final Clan clan;

    public CreateClanEvent(Clan clan) {
        this.clan = clan;
    }

    public Clan getClan() {
        return clan;
    }
}