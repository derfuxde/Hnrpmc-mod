package org.emil.hnrpmc.simpleclans.commands.completions;

import org.emil.hnrpmc.simpleclans.SimpleClans;

public abstract class AbstractAsyncCompletion extends AbstractCompletion {
    protected AbstractAsyncCompletion(SimpleClans plugin) {
        super(plugin);
    }
}
