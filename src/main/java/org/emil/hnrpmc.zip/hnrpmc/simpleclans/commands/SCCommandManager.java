package org.emil.hnrpmc.simpleclans.commands;

import co.aikar.commands.BaseCommand;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.tree.CommandNode;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import org.emil.hnrpmc.simpleclans.SimpleClans;
import org.emil.hnrpmc.simpleclans.commands.clan.*;
import org.emil.hnrpmc.simpleclans.commands.general.GeneralCommands;
import org.emil.hnrpmc.simpleclans.commands.staff.StaffCommands;
import org.emil.hnrpmc.simpleclans.managers.SettingsManager;
import org.emil.hnrpmc.world.WorldProtCommands;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

import static org.emil.hnrpmc.simpleclans.managers.SettingsManager.ConfigField.COMMANDS_CLAN;

@EventBusSubscriber(modid = "hnrpmc")
public final class SCCommandManager {

    private static SimpleClans plugin;

    public static void init(SimpleClans pluginInstance) {
        plugin = pluginInstance;
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        plugin = SimpleClans.getInstance();
        if (plugin == null) return;

        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        SettingsManager sm = plugin.getSettingsManager();

        List<String> aliases = parseAliases(sm.getString(COMMANDS_CLAN), "clan");
        String primary = aliases.get(0);

        ClanCommands clan = new ClanCommands(plugin);

        List<ClanSBaseCommand> commands = new ArrayList<>();
        commands.add(new ClanCommands(plugin));
        commands.add(new GeneralCommands(plugin));
        commands.add(new DataCommands(plugin));
        commands.add(new StaffCommands(plugin));
        commands.add(new ToggleCommand(plugin));
        commands.add(new RankCommand(plugin));
        commands.add(new HomeCommands(plugin));
        commands.add(new ChatCommand(plugin));
        commands.add(new VoterRegisterCommands(plugin));

        WorldProtCommands.register(dispatcher);

        for (ClanSBaseCommand command : commands) {
            CommandNode<CommandSourceStack> rootNode =
                    command.register(dispatcher, primary);

            for (int i = 1; i < aliases.size(); i++) {
                dispatcher.register(Commands.literal(aliases.get(i)).redirect(rootNode));
            }
        }
    }

    private static List<String> parseAliases(String configured, String fallback) {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        if (configured != null) {
            String cleaned = configured.replace(" ", "");
            for (String s : cleaned.split("\\|")) {
                String v = s.trim().toLowerCase(Locale.ROOT);
                if (!v.isEmpty()) set.add(v);
            }
        }
        String fb = fallback.trim().toLowerCase(Locale.ROOT);
        if (set.isEmpty()) set.add(fb);
        else set.add(fb);
        return new ArrayList<>(set);
    }
}
