package org.emil.hnrpmc.simpleclans.chat.handlers;

import org.emil.hnrpmc.simpleclans.Clan;
import org.emil.hnrpmc.simpleclans.chat.ChatHandler;
import org.emil.hnrpmc.simpleclans.chat.SCMessage;
import org.emil.hnrpmc.simpleclans.utils.ChatUtils;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.Optional;

import static org.emil.hnrpmc.simpleclans.ClanPlayer.Channel.CLAN;
import static org.emil.hnrpmc.simpleclans.chat.SCMessage.Source;
import static org.emil.hnrpmc.simpleclans.chat.SCMessage.Source.SPIGOT;
import static org.emil.hnrpmc.simpleclans.managers.SettingsManager.ConfigField.DISCORDCHAT_FORMAT_TO;

/**
 * Handles delivering messages from {@link Source#SPIGOT} to {@link Source#DISCORD}.
 */
public class DiscordChatHandler implements ChatHandler {

    @Override
    public void sendMessage(@NotNull SCMessage message) {
        if (message.getChannel() != CLAN) {
            return;
        }

        String format = settingsManager.getString(DISCORDCHAT_FORMAT_TO);
        String formattedMessage = ChatUtils.stripColors(chatManager.parseChatFormat(format, message));

        Clan clan = message.getSender().getClan();
        if (clan == null) {
            return;
        }
    }

    @Override
    public boolean canHandle(SCMessage.Source source) {
        return false;
    }
}
