package org.emil.hnrpmc.simpleclans.utils;

import net.minecraft.server.level.ServerPlayer;
import org.emil.hnrpmc.simpleclans.Helper;
import org.emil.hnrpmc.simpleclans.managers.PermissionsManager;
import org.emil.hnrpmc.simpleclans.managers.SettingsManager;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.regex.Pattern;

import static org.emil.hnrpmc.simpleclans.SimpleClans.lang;
import static org.emil.hnrpmc.simpleclans.managers.SettingsManager.ConfigField.*;

public class TagValidator {
    private final SettingsManager settings;
    private final PermissionsManager permissions;
    @Nullable
    private Pattern tagRegex;
    @Nullable
    private String error;

    public TagValidator(@NotNull SettingsManager settings, @NotNull PermissionsManager permissions) {
        this.settings = settings;
        this.permissions = permissions;

        String regex = settings.getString(TAG_REGEX);
        if (!regex.isEmpty()) {
            tagRegex = Pattern.compile(regex);
        }
    }

    /**
     * Validates a clan tag
     *
     * @param player player who tried to create a clan
     * @param tag    clan tag
     * @return error message if any
     */
    public Optional<String> validate(@NotNull Player player, @NotNull String tag) {
        error = null;
        String cleanTag = Helper.cleanTag(tag);
        if (tag.length() > 255 && settings.is(MYSQL_ENABLE)) {
            return Optional.of(lang("your.clan.color.tag.cannot.be.longer.than.characters", player, 255));
        }

        if (!permissions.has((ServerPlayer) player, "simpleclans.mod.bypass")) {
            if (settings.isDisallowedWord(cleanTag)) {
                error = lang("that.tag.name.is.disallowed", player);
            }
            if (!permissions.has((ServerPlayer) player, "simpleclans.leader.coloredtag") && tag.contains("&")) {
                error = lang("your.tag.cannot.contain.color.codes", player);
            }
            int minLength = settings.getInt(TAG_MIN_LENGTH);
            if (cleanTag.length() < minLength) {
                error = lang("your.clan.tag.must.be.longer.than.characters", player, minLength);
            }
            int maxLength = settings.getInt(TAG_MAX_LENGTH);
            if (cleanTag.length() > maxLength) {
                error = lang("your.clan.tag.cannot.be.longer.than.characters", player, maxLength);
            }
            if (settings.hasDisallowedColor(tag)) {
                error = lang("your.tag.cannot.contain.the.following.colors", player, settings.getDisallowedColorString());
            }
        }

        if (tagRegex == null) {
            checkAlphabet(player, cleanTag);
        } else if (!tagRegex.matcher(cleanTag).matches()) {
            error = lang("your.tag.doesnt.meet.the.requirements", player);
        }

        return Optional.ofNullable(error);
    }

    private void checkAlphabet(@NotNull Player player, @NotNull String cleanTag) {
        String alphabetError = lang("your.clan.tag.can.only.contain.letters.numbers.and.color.codes", player);
        if (settings.is(ACCEPT_OTHER_ALPHABETS_LETTERS)) {
            for (char c : cleanTag.toCharArray()) {
                if (!Character.isLetterOrDigit(c) || Character.isSpaceChar(c)) {
                    error = alphabetError;
                    return;
                }
            }
            return;
        }

        if (!cleanTag.matches("[0-9a-zA-Z]*")) {
            error = alphabetError;
        }
    }
}
