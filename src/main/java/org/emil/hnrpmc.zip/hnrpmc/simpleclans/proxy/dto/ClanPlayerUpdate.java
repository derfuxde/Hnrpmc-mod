package org.emil.hnrpmc.simpleclans.proxy.dto;

public final class ClanPlayerUpdate {
    public String uuid;
    public String name;
    public String clanTag;   // oder null
    public String rank;      // oder null
    public boolean verified;
}
