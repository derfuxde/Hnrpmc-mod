package org.emil.hnrpmc.simpleclans.commands;

import co.aikar.commands.BaseCommand;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.tree.RootCommandNode;
import net.minecraft.commands.CommandSourceStack;
import org.emil.hnrpmc.simpleclans.SimpleClans;

public abstract class ClanSBaseCommand {

    protected final SimpleClans plugin;

    protected ClanSBaseCommand(SimpleClans plugin) {
        this.plugin = plugin;
    }

    /**
     * Pflicht-Hook: wird nach ACF-Registrierung aufgerufen
     */
    public abstract RootCommandNode<CommandSourceStack> register(CommandDispatcher<CommandSourceStack> dispatcher, String rootLiteral);
}
