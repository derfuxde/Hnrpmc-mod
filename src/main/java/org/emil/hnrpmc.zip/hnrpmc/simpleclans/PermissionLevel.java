package org.emil.hnrpmc.simpleclans;

public enum PermissionLevel {
	LEADER, TRUSTED
}
