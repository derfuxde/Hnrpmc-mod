package org.emil.hnrpmc.simpleclans.commands.clan;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.server.level.ServerPlayer;
import org.emil.hnrpmc.simpleclans.Clan;
import org.emil.hnrpmc.simpleclans.Rank;
import org.emil.hnrpmc.simpleclans.SimpleClans;

import java.util.List;

import static net.minecraft.commands.SharedSuggestionProvider.suggest;

public final class Suggestions {

    public static SuggestionProvider<CommandSourceStack> clansHideOwn(SimpleClans plugin) {
        return (ctx, b) -> suggest(plugin.getClanManager().getAllClanTagsHideOwn(ctx.getSource()), b);
    }

    public static SuggestionProvider<CommandSourceStack> rivals(SimpleClans plugin) {
        return (ctx, b) -> suggest(plugin.getClanManager().getRivalTags(ctx.getSource()), b);
    }

    public static SuggestionProvider<CommandSourceStack> alliedClans(SimpleClans plugin) {
        return (ctx, b) -> suggest(plugin.getClanManager().getAlliedTags(ctx.getSource()), b);
    }

    public static SuggestionProvider<CommandSourceStack> notsamerank(SimpleClans plugin) {
        return (ctx, b) -> {
            try {
                // Hier holen wir den Rank dynamisch aus dem Kontext des aktuellen Befehls
                String rank = StringArgumentType.getString(ctx, "rank");

                // Jetzt rufen wir deine Logik auf
                return suggest(plugin.getClanManager().getPlayerwithRank(ctx.getSource(), rank, true), b);
            } catch (IllegalArgumentException e) {
                // Falls "rank" aus irgendeinem Grund nicht gefunden wird, leere Vorschläge
                return b.buildFuture();
            }
        };
    }

    public static SuggestionProvider<CommandSourceStack> warringClans(SimpleClans plugin) {
        return (ctx, b) -> suggest(plugin.getClanManager().getWarringTags(ctx.getSource()), b);
    }

    public static SuggestionProvider<CommandSourceStack> getAllRanks(SimpleClans plugin) {
        return (ctx, builder) -> {
            ServerPlayer player = ctx.getSource().getPlayer();
            if (player == null) return builder.buildFuture();

            // 1. Clan holen
            Clan clan = plugin.getClanManager().getClanByPlayerName(player.getName().getString());

            // 2. Prüfen, ob der Clan existiert (Null-Check!)
            if (clan == null) {
                // Wenn kein Clan gefunden wurde, schlage nichts vor oder gib eine leere Liste zurück
                return builder.buildFuture();
            }

            List<String> rankNames = clan.getRanks().stream()
                    .map(rank -> rank.getName()) // oder rank.getDisplayName()
                    .toList();
            // 3. Nur wenn der Clan nicht null ist, auf getRanks() zugreifen
            return SharedSuggestionProvider.suggest(rankNames, builder);
        };
    }

    public static SuggestionProvider<CommandSourceStack> nonMembers(SimpleClans plugin) {
        return (ctx, b) -> suggest(plugin.getClanManager().getOnlineNonMembers(ctx.getSource()), b);
    }

    public static SuggestionProvider<CommandSourceStack> clanMembersHideOwn(SimpleClans plugin) {
        return (ctx, b) -> suggest(plugin.getClanManager().getOnlineClanMembersHideOwn(ctx.getSource()), b);
    }
}
