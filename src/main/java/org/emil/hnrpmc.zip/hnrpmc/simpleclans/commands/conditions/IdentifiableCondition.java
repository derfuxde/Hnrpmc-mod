package org.emil.hnrpmc.simpleclans.commands.conditions;

import org.jetbrains.annotations.NotNull;

public interface IdentifiableCondition {
    @NotNull
    String getId();
}
