//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package org.emil.hnrpmc.simpleclans.conversation.dings;

import org.emil.hnrpmc.simpleclans.conversation.RequestCanceller;
import org.emil.hnrpmc.simpleclans.conversation.SCConversation;
import org.jetbrains.annotations.NotNull;

public class ManuallyAbandonedConvoCanceller implements ConvoCanceller {
    public void setConversation(@NotNull ClanConvo conversation) {
        throw new UnsupportedOperationException();
    }

    public boolean cancelBasedOnInput(@NotNull SCConversation context, @NotNull String input) {
        throw new UnsupportedOperationException();
    }

    public @NotNull ConvoCanceller clone() {
        throw new UnsupportedOperationException();
    }
}
