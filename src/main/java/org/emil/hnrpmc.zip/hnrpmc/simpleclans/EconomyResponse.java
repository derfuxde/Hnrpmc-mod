package org.emil.hnrpmc.simpleclans;

public enum EconomyResponse {
    SUCCESS, NEGATIVE_VALUE, NOT_ENOUGH_BALANCE, CANCELLED
}
