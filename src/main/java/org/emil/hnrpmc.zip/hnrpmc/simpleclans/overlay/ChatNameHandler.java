package org.emil.hnrpmc.simpleclans.overlay;

import com.hypherionmc.sdlink.api.accounts.DiscordAuthor;
import com.hypherionmc.sdlink.api.messaging.MessageType;
import com.hypherionmc.sdlink.api.messaging.discord.DiscordMessage;
import com.hypherionmc.sdlink.api.messaging.discord.DiscordMessageBuilder;
import com.hypherionmc.sdlink.core.config.SDLinkConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.CommandEvent;
import net.neoforged.neoforge.event.ServerChatEvent;

import org.emil.hnrpmc.Hnrpmc;
import org.emil.hnrpmc.simpleclans.Clan;
import org.emil.hnrpmc.simpleclans.SimpleClans;
import org.emil.hnrpmc.simpleclans.config.NameRulesStore;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.mojang.text2speech.Narrator.LOGGER;
import static org.emil.hnrpmc.simpleclans.chat.ChatHandler.settingsManager;
import static org.emil.hnrpmc.simpleclans.managers.SettingsManager.ConfigField.CLANCHAT_TAG_BASED;
import static org.emil.hnrpmc.simpleclans.managers.SettingsManager.ConfigField.COMMANDS_CLAN_CHAT;
import static org.emil.hnrpmc.simpleclans.overlay.NameDisplayService.pickRule;

@EventBusSubscriber(modid = Hnrpmc.MODID)
public final class ChatNameHandler {

    private static SimpleClans plugin;

    private static List<UUID> makenametag = new ArrayList<>();

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onPlayerCommand(CommandEvent event) {
        CommandSourceStack source = event.getParseResults().getContext().getSource();

        // Prüfen, ob der Sender ein Spieler ist
        if ((source.getEntity() instanceof ServerPlayer player)) {
            makenametag.add(player.getUUID());
        }
    }

    @SubscribeEvent
    public static void onChat(ServerChatEvent event) {
        ServerPlayer p = event.getPlayer();
        if (p == null) return;

        if (plugin == null) {
            plugin = SimpleClans.getInstance();
        }

        if (makenametag.contains(p.getUUID())) {

        }


        event.setCanceled(true);
        //p.sendSystemMessage(Component.literal("Dein Chat ist auf §7diesem Server deaktiviert."));
        String nameFormatted = NameDisplayService.formatForChat(plugin, p).replace("%message%", event.getMessage().getString());
        NameRulesStore.Root root = NameRulesStore.get(p.server);
        NameRulesStore.Rule rule = pickRule(plugin, root.rules(), p, "tablist");
        makenametag.remove(p.getUUID());
        if (SDLinkConfig.INSTANCE != null) {
            try {
                String displayname = ClanScoreboard.formatplaceholder(plugin, rule.format(), p);

                DiscordAuthor author = DiscordAuthor.of(displayname, p.getStringUUID(), p.getGameProfile().getName());
                DiscordMessage message1 = new DiscordMessageBuilder(MessageType.CHAT)
                        .message(event.getMessage().getString())
                        .author(author)
                        .build();

                message1.sendMessage();
            } catch (Throwable t) {
                LOGGER.warn("SDLink not ready, skipping Discord send", t);

            }
        }

        for (ServerPlayer sp : p.getServer().getPlayerList().getPlayers()) {
            sp.sendSystemMessage(Component.literal(nameFormatted));
        }

    }
}
