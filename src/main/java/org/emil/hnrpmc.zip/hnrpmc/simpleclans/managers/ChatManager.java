package org.emil.hnrpmc.simpleclans.managers;

import org.emil.hnrpmc.simpleclans.Clan;
import org.emil.hnrpmc.simpleclans.ClanPlayer;
import org.emil.hnrpmc.simpleclans.Helper;
import org.emil.hnrpmc.simpleclans.SimpleClans;
import org.emil.hnrpmc.simpleclans.chat.ChatHandler;
import org.emil.hnrpmc.simpleclans.chat.SCMessage;
import org.emil.hnrpmc.simpleclans.overlay.ClanScoreboard;
import org.emil.hnrpmc.simpleclans.utils.ChatUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.InvocationTargetException;
import java.util.*;
import java.util.logging.Level;
import java.util.stream.Collectors;

import static java.util.logging.Level.INFO;
import static java.util.logging.Level.SEVERE;
import static org.emil.hnrpmc.simpleclans.ClanPlayer.Channel;
import static org.emil.hnrpmc.simpleclans.chat.SCMessage.Source;
import static org.emil.hnrpmc.simpleclans.chat.SCMessage.Source.DISCORD;
import static org.emil.hnrpmc.simpleclans.managers.SettingsManager.ConfigField;
import static org.emil.hnrpmc.simpleclans.managers.SettingsManager.ConfigField.*;

public final class ChatManager {

    private final SimpleClans plugin;
    private final Set<ChatHandler> handlers = new HashSet<>();

    public ChatManager(SimpleClans plugin) {
        this.plugin = plugin;
        registerHandlers();
    }

    public void processChat(@NotNull SCMessage message) {
        Clan clan = Objects.requireNonNull(message.getSender().getClan(), "Clan cannot be null");

        List<ClanPlayer> receivers = new ArrayList<>();
        switch (message.getChannel()) {
            case ALLY:
                if (!plugin.getSettingsManager().is(ALLYCHAT_ENABLE)) {
                    return;
                }

                receivers.addAll(getOnlineAllyMembers(clan).stream().filter(allyMember ->
                        !allyMember.isMutedAlly()).collect(Collectors.toList()));
                receivers.addAll(clan.getOnlineMembers().stream().filter(onlineMember ->
                        !onlineMember.isMutedAlly()).collect(Collectors.toList()));
                break;
            case CLAN:
                if (!plugin.getSettingsManager().is(CLANCHAT_ENABLE)) {
                    return;
                }

                receivers.addAll(clan.getOnlineMembers().stream().filter(member -> !member.isMuted()).
                        collect(Collectors.toList()));
        }
        message.setReceivers(receivers);

        for (ChatHandler ch : handlers) {
            if (ch.canHandle(message.getSource())) {
                ch.sendMessage(message.clone());
            }
        }
    }

    public void processChat(@NotNull Source source, @NotNull Channel channel,
                            @NotNull ClanPlayer clanPlayer, String message) {
        Objects.requireNonNull(clanPlayer.getClan(), "Clan cannot be null");
        processChat(new SCMessage(source, channel, clanPlayer, message));
    }

    public String parseChatFormat(String format, SCMessage message) {
        return parseChatFormat(format, message, new HashMap<>());
    }

    public String parseChatFormat(String format, SCMessage message, Map<String, String> placeholders) {
        SettingsManager sm = plugin.getSettingsManager();
        ClanPlayer sender = message.getSender();

        String leaderColor = sm.getColored(ConfigField.valueOf(message.getChannel() + "CHAT_LEADER_COLOR"));
        String memberColor = sm.getColored(ConfigField.valueOf(message.getChannel() + "CHAT_MEMBER_COLOR"));
        String trustedColor = sm.getColored(ConfigField.valueOf(message.getChannel() + "CHAT_TRUSTED_COLOR"));

        String rank = sender.getRankId().isEmpty() ? null : ChatUtils.parseColors(sender.getRankDisplayName());
        ConfigField configField = ConfigField.valueOf(String.format("%sCHAT_RANK",
                message.getSource() == DISCORD ? "DISCORD" : message.getChannel()));
        String rankFormat = (rank != null) ? sm.getColored(configField).replace("%rank%", rank) : "";

        if (placeholders != null) {
            for (Map.Entry<String, String> e : placeholders.entrySet()) {
                format = format.replace("%" + e.getKey() + "%", e.getValue());
            }
        }

        String parsedFormat = ChatUtils.parseColors(format)
                .replace("%clan%", Objects.requireNonNull(sender.getClan()).getColorTag())
                .replace("%clean-tag%", sender.getClan().getTag())
                .replace("%nick-color%",
                        (sender.isLeader() ? leaderColor : sender.isTrusted() ? trustedColor : memberColor))
                .replace((CharSequence) "%player%", (CharSequence) sender.getName())
                .replace("%rank%", rankFormat);

        String secoparsedFormat = ClanScoreboard.formatplaceholder(plugin, parsedFormat, sender.toPlayer());

        return secoparsedFormat;
    }

    private void registerHandlers() {
        Set<Class<? extends ChatHandler>> chatHandlers =
                Helper.getSubTypesOf("org.emil.hnrpmc.simpleclans.chat.handlers", ChatHandler.class);
        plugin.getLogger().info("Registering {0} chat handlers...", chatHandlers.size());

        for (Class<? extends ChatHandler> handler : chatHandlers) {
            try {
                handlers.add(handler.getConstructor().newInstance());
            } catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException ex) {
                plugin.getLogger().info("Error while trying to register {0}: ",
                        ex.getMessage(), handler.getSimpleName());
            }
        }
    }

    private List<ClanPlayer> getOnlineAllyMembers(Clan clan) {
        return clan.getAllAllyMembers().stream().
                filter(allyPlayer -> allyPlayer.toPlayer() != null).
                collect(Collectors.toList());
    }
}
