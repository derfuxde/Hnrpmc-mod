package org.emil.hnrpmc.simpleclans.migrations;

public interface Migration {

    void migrate();
}
