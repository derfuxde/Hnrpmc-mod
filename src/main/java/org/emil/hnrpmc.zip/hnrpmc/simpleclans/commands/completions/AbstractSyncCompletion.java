package org.emil.hnrpmc.simpleclans.commands.completions;

import org.emil.hnrpmc.simpleclans.SimpleClans;

public abstract class AbstractSyncCompletion extends AbstractCompletion {
    protected AbstractSyncCompletion(SimpleClans plugin) {
        super(plugin);
    }
}
